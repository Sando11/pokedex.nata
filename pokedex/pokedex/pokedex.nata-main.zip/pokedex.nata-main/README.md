# pokedex.nata
**PARA RODAR O SISTEMA DEVE ABRIR O ARQUIVO INDEX.HTML

Ao entrar no sistema o usuário irá ter uma tela com uma lista de pokémon, sendo possível passar de página e visualizar mais pokémons
e logo ao lado um botão interativo com todos os pokémons que o usuário supostamente tivesse capturado.

Neste projeto "Minha Pokedex" dentre os tópicos passados, os que foram realizados foram :
* Lista de pokémons, contendo (HP, ATAQUE, DEFESA)
* Tela com pokémons capturados, contendo (HP, ATAQUE, DEFESA)

Os que não foram realizados foram: 

* botão de capturar em cada pokémon
* * visualização da data e hora dos pokémons capturados 

